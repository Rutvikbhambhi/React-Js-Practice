import './App.css';
import {createContext, useEffect, useReducer, useState} from 'react';

// function App(props) {
// // useState
//   const [count, setCount] = useState(0);
//   const [online, setOnline] = useState(null);

// // useEffect
//   useEffect(() => {
//     document.title = `You Clicked ${count} times`;
//   });

//   // return <div>I'm logging to console "{message}"</div>;

  
//   return (
//     <div className="App">
//       {/* useState */}
//       <h2>Rutvik {count}</h2>
//       <button onClick={ () => setCount (count + 1)}>Increament</button>
//       <button onClick={ () => setCount (count - 1)}>Decreament</button>
//     </div>
//   );
// }

// export default App;




// useReducer
function reducer(state, action) {
  if (action.type === 'incremented_age') {
    return {
      age: state.age + 1
    };
  }
  throw Error('Unknown action.');
}

export default function Counter() {
  const [state, dispatch] = useReducer(reducer, { age: 42 });

  return (
    <>
      <button onClick={() => {
        dispatch({ type: 'incremented_age' })
      }}>
        Increment age
      </button>
      <p>Hello! You are {state.age}.</p>
    </>
  );
}


// useContext
// const App = createContext()
// function DarkModeProvider (props) {
//   const [darkMode, setDarkMode] = useState(false);
//   const toggleDarkMode = () => {
//     setDarkMode(!darkMode);
//   };  
//   return (
//     <div>
//       <DarkModeContext.provider value={{darkMode, toggleDarkMode}}>
//         {props.children}
//       </DarkModeContext.provider>
//     </div>
//   )
// }

// export {DarkModeContext, DarkModeProvider};
